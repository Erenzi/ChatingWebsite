package de.maxhenkel.voicechat.voice.client;

import java.io.IOException;

public class MicrophoneException extends IOException {

    public MicrophoneException(String message) {
        super(message);
    }

}
