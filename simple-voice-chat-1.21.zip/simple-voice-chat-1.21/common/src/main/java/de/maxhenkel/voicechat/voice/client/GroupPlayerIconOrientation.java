package de.maxhenkel.voicechat.voice.client;

public enum GroupPlayerIconOrientation {

    VERTICAL, HORIZONTAL

}
