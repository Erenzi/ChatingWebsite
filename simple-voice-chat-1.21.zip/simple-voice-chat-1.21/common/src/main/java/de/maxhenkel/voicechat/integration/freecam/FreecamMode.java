package de.maxhenkel.voicechat.integration.freecam;

public enum FreecamMode {

    CAMERA, PLAYER

}
