# Simple Voice Chat API

> **Warning**
> This page has been moved. Click [here](https://modrepo.de/minecraft/voicechat/api/overview)!
