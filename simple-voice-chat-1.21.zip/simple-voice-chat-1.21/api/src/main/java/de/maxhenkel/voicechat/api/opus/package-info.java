/**
 * Wrappers for the Opus codec.
 */
package de.maxhenkel.voicechat.api.opus;