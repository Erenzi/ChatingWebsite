package de.maxhenkel.voicechat.api;

public interface ServerLevel {

    /**
     * @return the actual level object
     */
    Object getServerLevel();

}
