package de.maxhenkel.voicechat.api.events;

public interface VoicechatServerStoppedEvent extends ServerEvent {

}
