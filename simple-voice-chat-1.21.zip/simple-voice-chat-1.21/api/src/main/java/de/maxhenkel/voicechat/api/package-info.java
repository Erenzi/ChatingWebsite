/**
 * The main Simple Voice Chat API package.
 */
package de.maxhenkel.voicechat.api;