/**
 * All registerable events.
 * <p>
 * Events can be registered by calling {@link de.maxhenkel.voicechat.api.events.EventRegistration#registerEvent}.
 */
package de.maxhenkel.voicechat.api.events;