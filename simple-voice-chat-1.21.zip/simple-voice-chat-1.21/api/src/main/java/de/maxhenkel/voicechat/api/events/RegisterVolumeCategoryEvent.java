package de.maxhenkel.voicechat.api.events;

public interface RegisterVolumeCategoryEvent extends VolumeCategoryEvent {

}
