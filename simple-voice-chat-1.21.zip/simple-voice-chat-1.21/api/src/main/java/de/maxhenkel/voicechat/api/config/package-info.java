/**
 * Everything configuration related.
 */
package de.maxhenkel.voicechat.api.config;