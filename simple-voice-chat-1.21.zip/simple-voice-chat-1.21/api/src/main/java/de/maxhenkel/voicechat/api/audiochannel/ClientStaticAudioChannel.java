package de.maxhenkel.voicechat.api.audiochannel;

public interface ClientStaticAudioChannel extends ClientAudioChannel {

}
