/**
 * Wrappers for mp3 encoding and decoding.
 */
package de.maxhenkel.voicechat.api.mp3;