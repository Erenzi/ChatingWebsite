/**
 * Everything related to audio channels and serverside audio.
 */
package de.maxhenkel.voicechat.api.audiochannel;