package de.maxhenkel.voicechat.api.audiochannel;

public interface StaticAudioChannel extends AudioChannel {

}
