package de.maxhenkel.voicechat.api.packets;

public interface Packet {
}
