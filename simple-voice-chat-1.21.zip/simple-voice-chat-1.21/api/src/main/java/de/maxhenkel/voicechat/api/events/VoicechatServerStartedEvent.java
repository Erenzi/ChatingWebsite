package de.maxhenkel.voicechat.api.events;

public interface VoicechatServerStartedEvent extends ServerEvent {

}
