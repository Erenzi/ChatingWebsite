package de.maxhenkel.voicechat.api.events;

public interface UnregisterVolumeCategoryEvent extends VolumeCategoryEvent {

}
