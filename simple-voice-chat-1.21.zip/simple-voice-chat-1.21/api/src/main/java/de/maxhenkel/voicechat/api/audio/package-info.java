/**
 * Everything related to audio conversion and manipulation.
 */
package de.maxhenkel.voicechat.api.audio;