/**
 * All voice chat UDP packets.
 */
package de.maxhenkel.voicechat.api.packets;