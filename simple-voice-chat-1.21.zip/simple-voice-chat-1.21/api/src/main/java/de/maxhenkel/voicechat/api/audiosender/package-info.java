/**
 * Utilities for simulating players sending audio without the mod.
 * <p>
 * Can be obtained by calling {@link de.maxhenkel.voicechat.api.VoicechatServerApi#createAudioSender(de.maxhenkel.voicechat.api.VoicechatConnection)}.
 */
package de.maxhenkel.voicechat.api.audiosender;