package de.maxhenkel.voicechat;

public class BuildConstants {

    public static final String MOD_VERSION = "${mod_version}";

}
